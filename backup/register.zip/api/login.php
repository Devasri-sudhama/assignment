<?php

session_start();
require './config.php';
require './uploads.php';

// print_r($_POST);
// echo '<script type="text/javascript">alert("' . $_POST . '")</script>';
$post = $_POST;
$errors = [];
$email = $_POST["email"];
$password = $_POST["password"];
$sql = "select id,email,name,role,status from users where email = '$email' and password = '$password'";
$result = mysqli_query($conn, $sql);

// $sql = "select email from users where email = '$email'";
$result = mysqli_query($conn, $sql);
$rowcount = mysqli_num_rows($result);

// if ($result) 
//     echo json_encode(array("statusCode" => 200));
//     // mysqli_close($mysqli);
//     // exit(0);
// else {
//     echo json_encode(array("statusCode" => 201));
//     // exit(0);
// }
$row=mysqli_fetch_array($result);

// if($row=mysqli_fetch_array($result))
//  {
//   $_SESSION['email']=$email;
//   echo json_encode(array("statusCode" => 200,"email"=>$_SESSION['email']));
// //   $_SESSION['email']=$row['email'];
// header("Location:http://localhost/ReferenceGlobe/dashboard.php");
// exit();
// //   echo "success";
//  }

if(is_array($row)) {
    $_SESSION["id"] = $row['id'];
    $_SESSION["role"] = $row['role'];
    $_SESSION["name"] = $row['name'];
    $_SESSION["email"] = $row['email'];
    $_SESSION["status"] = $row['status'];
    // header("Location:../dashboard.php");
    echo json_encode(array("statusCode" => 200));
    } else{
    echo json_encode(array("statusCode" => 201,"msg"=>"Invalid Details"));
 }
//  if(isset($_SESSION["id"])) {
//     header("Location:../dashboard.php");
//     }
    
    // $result = $mysqli->query($sql);


    //  $sql = "SELECT * FROM users Order by id desc LIMIT 1";


    // $result = $mysqli->query($sql);


    // $data = $result->fetch_assoc();
    // echo json_encode($data);
    // exit(0);
?>