<!DOCTYPE html>
<html>

<?php include('header.php');
session_start();
if (isset($_SESSION['name'])) {

?>

	<body>
		<ul>
			<li><a href="#home">Home</a></li>

			<li style="float:right"><a type="button" id="logout" class="active" href="#">Logout</a></li>
		</ul>

		<div class="container">
			<?php if ($_SESSION['status'] == 0) { ?>

				<div class="alert alert-warning" role="alert">
					Needs Admin Approval..
				</div>
			<?php } else if ($_SESSION['role'] == 1) { ?>
				<div class="row">
					<div class="col-lg-12 margin-tb">
						<div class="pull-left">
							<div class="input-group">
								<div class="form-outline">
									<input type="search" id="search" name="search" class="search form-control" required />
									<button type="submit" id="search-btn" class="btn btn-primary search-btn">Search
										<i class="fas fa-search"></i>
									</button>
								</div>

							</div>
						</div>
						<div class="pull-right">
							<button type="button" class="btn btn-success" data-toggle="modal" data-target="#create-item">
								Create Item
							</button>
						</div>
					</div>
				</div>

				<table id="records" class="table table-bordered">
					<thead>
						<tr>
							<th>Id</th>
							<th>Name</th>
							<th>role</th>
							<th>email</th>
							<th>Address</th>
							<th>Profile</th>
							<th width="200px">Date of Birth</th>
							<th>Status</th>
							<th width="200px">Creation Date</th>
							<th >Updated By</th>
							<th width="200px">Action</th>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			<?php } ?>

			<div id="norecords" class="alert alert-warning" role="alert">
				<p>no records</p>
			</div>
			<ul id="pagination" class="pagination-sm">

			</ul>
			<ul id="searchPagination" class="pagination-sm">

			</ul>

			<div class="pull-right">
				<button type="button" class="btn btn-success" data-toggle="modal" data-target="#create-item">
					Create Item
				</button>
			</div>
			<!-- Create Item Modal -->
			<div class="modal fade" id="create-item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
							<h4 class="modal-title" id="myModalLabel"></h4>
						</div>
						<div class="modal-body">
							<div class="alert alert-success alert-dismissible" id="success">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
							</div>
							<div class="alert alert-danger alert-dismissible" id="error">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
							</div>
							<form data-toggle="validator" action="api/create.php" method="POST">
								<div class="form-group">
									<label class="control-label" for="title">Name:</label>
									<input type="text" name="name" id="name" class="form-control" data-error="Please enter title." required />
									<div class="help-block with-errors"></div>
								</div>
								<div class="form-group">
									<label class="control-label" for="title">Mobile:</label>
									<input type="text" name="mobile" id="mobile" class="form-control" data-error="Please enter title." required />
									<div class="help-block with-errors"></div>
								</div>
								<div class="form-group">
									<label class="control-label" for="title">Email:</label>
									<input type="email" name="email" id="email" class="form-control" data-error="Please enter title." required />
									<div class="help-block with-errors"></div>
								</div>
								<!-- <div class="form-group">
									<label class="control-label" for="title">Password:</label>
									<input type="text" name="title" class="form-control" data-error="Please enter title." required />
									<div class="help-block with-errors"></div>
								</div> -->
								<label for="html" class=""><b>Profile Picture:</b><br />
									<div id="preview"></div>
									<input type="file" name="fileToUpload" id="fileToUpload" required>
									<!-- <input type="button" id="upload" name="upload"> -->
								</label>
								<div class="form-group">
									<label class="control-label" for="title">Date of Birth:</label>
									<input type="date" name="dateofbirth" id="dateofbirth" class="form-control" data-error="Please enter title." required />
									<div class="help-block with-errors"></div>
								</div>
								<div class="form-group">
									<label class="control-label" for="title">Address:</label>
									<input type="text" name="address" id="address" class="form-control" data-error="Please enter title." required />
									<div class="help-block with-errors"></div>
								</div>
								<div class="form-group">
									<label class="control-label" for="title">Gender:</label>
									<label for="one">
										  <label for="css">Male</label>
										<input type="radio" id="gender" name="gender" class="radio-inline" value="Male" required>
										  <input type="radio" id="gender" name="gender" class="radio-inline" value="Female" required>
										<label for="css">Female</label>
										<div class="help-block with-errors"></div>
									</label>
								</div>
								<!-- <div class="form-group">
									<label class="control-label" for="title">Description:</label>
									<textarea name="description" class="form-control" data-error="Please enter description." required></textarea>
									<div class="help-block with-errors"></div>
								</div> -->
								<div class="form-group">
									<button type="submit" class="btn crud-submit btn-success">Submit</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>


			<!-- Edit Item Modal -->
			<div class="modal fade" id="edit-item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
								<h4 class="modal-title" id="myModalLabel"></h4>
							</div>
							<div class="modal-body">

								<div class="alert alert-success alert-dismissible" id="success">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
								</div>
								<div class="alert alert-danger alert-dismissible" id="error">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
								</div>
								<form data-toggle="validator" action="api/update.php" method="POST">
									<div class="form-group">
										<label class="control-label" for="title">Name:</label>
										<input type="text" name="name" id="name" class="form-control" data-error="Please enter title." required />
										<div class="help-block with-errors"></div>
									</div>
									<div class="form-group">
										<label class="control-label" for="title">Mobile:</label>
										<input type="text" name="mobile" id="mobile" class="form-control" data-error="Please enter title." required />
										<div class="help-block with-errors"></div>
									</div>
									<div class="form-group">
										<label class="control-label" for="title">Email:</label>
										<input type="email" name="email" id="email" class="form-control" data-error="Please enter title." required disabled/>
										<div class="help-block with-errors"></div>
									</div>
									<!-- <div class="form-group">
									<label class="control-label" for="title">Password:</label>
									<input type="text" name="title" class="form-control" data-error="Please enter title." required />
									<div class="help-block with-errors"></div>
								</div> -->
								<label for="html" class=""><b>Profile Picture:</b><br />
									<div id="preview1"></div>
									
									<input type="file" name="fileToUpload-edit" id="fileToUpload-edit">
									<!-- <input type="button" id="upload" name="upload"> -->
									<img name="profile" id="profile" width="200px" height="100px"/>
								</label>
									<div class="form-group">
										<label class="control-label" for="title">Date of Birth:</label>
										<input type="date" name="dateofbirth" id="dateofbirth" class="form-control" data-error="Please enter title." required />
										<div class="help-block with-errors"></div>
									</div>
									<div class="form-group">
										<label class="control-label" for="title">Address:</label>
										<input type="text" name="address" id="address" class="form-control" data-error="Please enter title." required />
										<div class="help-block with-errors"></div>
									</div>
									<div class="form-group">
										<label class="control-label" for="title">Gender:</label>
										<label for="one">
											  <label for="css">Male</label>
											<input type="radio" id="gender" name="gender" class="radio-inline" value="Male" required>
											  <input type="radio" id="gender" name="gender" class="radio-inline" value="Female" required>
											<label for="css">Female</label>
											<div class="help-block with-errors"></div>
										</label>
									</div>

									<div class="form-group">
										<button type="submit" class="btn btn-success crud-submit-edit">Submit</button>
									</div>


								</form>


							</div>
						</div>
					</div>
				</div>


			</div>
		<?php } else {
		header("Location:http://localhost/SystemTask/index.php");
	} ?>
	</body>

</html>